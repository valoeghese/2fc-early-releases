2fc0f18 - 0.3.0
Released Mar 2022
Built and Packaged for Windows Apr 2025

Please download 2fc0f18-0.3.0-libs.zip and extract the contents to the 'lib' folder.
To start the game, run the provided batch file.